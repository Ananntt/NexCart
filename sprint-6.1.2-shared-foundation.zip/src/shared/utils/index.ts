/**
 * Universally useful, framework-agnostic helper functions.
 *
 * Intentionally excluded (future sprints): date/time, string, search,
 * formatting helpers — those get their own dedicated modules when needed.
 */

/**
 * Asserts that `condition` is truthy, narrowing types accordingly.
 * Throws an Error (not a domain-specific error type — none exists yet
 * at this layer) if the condition is false.
 */
export function assert(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new Error(message);
  }
}

/** True if `value` is neither null nor undefined. Narrows accordingly. */
export function isDefined<T>(value: T | null | undefined): value is T {
  return value !== null && value !== undefined;
}

/** True if `value` is null or undefined. */
export function isNullish(value: unknown): value is null | undefined {
  return value === null || value === undefined;
}

/**
 * Asserts that a code path is unreachable — useful for exhaustive
 * switch/if-else checks over a union type. Fails at compile time if
 * `value` is not actually `never`, and at runtime if somehow reached.
 */
export function assertNever(value: never): never {
  throw new Error(`Unreachable code reached with value: ${JSON.stringify(value)}`);
}
