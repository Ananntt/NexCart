/**
 * Generic, framework-agnostic type primitives shared across the whole
 * backend. Nothing here is tied to a specific feature, layer, or library.
 *
 * Intentionally excluded (future sprints): Result<T, E>, RequestContext.
 */

/** A value that may be null (but is always present, unlike Optional). */
export type Nullable<T> = T | null;

/** A value that may be omitted entirely (but is never null, unlike Nullable). */
export type Optional<T> = T | undefined;

/** A value that may be missing or null. */
export type Maybe<T> = T | null | undefined;

/** The set of JavaScript primitive value types. */
export type Primitive = string | number | boolean | null | undefined;

/** Any value representable in JSON. */
export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

/** A JSON value that is specifically an object (not an array or scalar). */
export type JsonObject = { [key: string]: JsonValue };
