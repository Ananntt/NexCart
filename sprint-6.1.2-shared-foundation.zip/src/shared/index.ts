/**
 * Public entry point for the Shared Foundation layer.
 * Every consumer imports from `@/shared`, never from
 * `@/shared/types` or `@/shared/utils` directly.
 */

export type {
  Nullable,
  Optional,
  Maybe,
  Primitive,
  JsonValue,
  JsonObject,
} from './types';

export { assert, isDefined, isNullish, assertNever } from './utils';
