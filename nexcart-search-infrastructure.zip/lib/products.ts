import type { Product } from '@/types/product';
import type { SearchFilters, SearchResult, SearchSortOption } from '@/types/search';

/**
 * Mock product dataset + pure helper functions.
 *
 * This is a temporary, frontend-only data source standing in for the real
 * `GET /v1/search` / `GET /v1/products` endpoints (docs/api.md §2, §3),
 * which depend on the DB/search pipeline not yet implemented (Sprint 6.1
 * explicitly excludes DB, providers, and business logic). Helpers here are
 * written as pure functions over static data so they are easy to delete or
 * swap for real API calls later without the calling components changing
 * shape (same input/output contracts).
 */

function computeDiscount(current: number, mrp: number): number {
  if (mrp <= 0) return 0;
  return Math.round(((mrp - current) / mrp) * 100);
}

function price(current: number, mrp: number): Product['price'] {
  return { current, mrp, discountPercent: computeDiscount(current, mrp), currency: 'INR' };
}

export const PRODUCTS: Product[] = [
  {
    id: 'p001',
    slug: 'apple-iphone-15-128gb-black',
    title: 'Apple iPhone 15 (128GB) - Black',
    brand: 'Apple',
    category: 'mobiles',
    store: 'amazon',
    price: price(65999, 79900),
    rating: { average: 4.6, count: 18234 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/iphone-15-black.jpg',
    description: 'A17 Bionic chip, 48MP main camera, Dynamic Island, USB-C.',
    attributes: { ram: '6GB', storage: '128GB', color: 'Black', display: '6.1"' },
    productUrl: 'https://www.amazon.in/dp/mock-p001',
  },
  {
    id: 'p002',
    slug: 'samsung-galaxy-s24-256gb-violet',
    title: 'Samsung Galaxy S24 (256GB) - Violet',
    brand: 'Samsung',
    category: 'mobiles',
    store: 'flipkart',
    price: price(72999, 84999),
    rating: { average: 4.5, count: 9821 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/galaxy-s24-violet.jpg',
    description: 'Snapdragon 8 Gen 3, Galaxy AI features, 50MP triple camera.',
    attributes: { ram: '8GB', storage: '256GB', color: 'Violet', display: '6.2"' },
    productUrl: 'https://www.flipkart.com/mock-p002',
  },
  {
    id: 'p003',
    slug: 'oneplus-12-256gb-flowy-emerald',
    title: 'OnePlus 12 (256GB) - Flowy Emerald',
    brand: 'OnePlus',
    category: 'mobiles',
    store: 'croma',
    price: price(64999, 69999),
    rating: { average: 4.4, count: 3120 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 4,
    image: '/products/oneplus-12-emerald.jpg',
    description: 'Snapdragon 8 Gen 3, Hasselblad camera, 100W SUPERVOOC charging.',
    attributes: { ram: '12GB', storage: '256GB', color: 'Flowy Emerald', display: '6.82"' },
    productUrl: 'https://www.croma.com/mock-p003',
  },
  {
    id: 'p004',
    slug: 'xiaomi-14-civi-512gb-white',
    title: 'Xiaomi 14 Civi (512GB) - White',
    brand: 'Xiaomi',
    category: 'mobiles',
    store: 'reliance_digital',
    price: price(44999, 49999),
    rating: { average: 4.2, count: 1560 },
    stockStatus: 'limited',
    deliveryEtaDays: 5,
    image: '/products/xiaomi-14-civi-white.jpg',
    description: 'Leica-tuned cameras, Snapdragon 8s Gen 3, slim design.',
    attributes: { ram: '12GB', storage: '512GB', color: 'White', display: '6.55"' },
    productUrl: 'https://www.reliancedigital.in/mock-p004',
  },
  {
    id: 'p005',
    slug: 'apple-macbook-air-m3-13-256gb',
    title: 'Apple MacBook Air M3 13" (256GB)',
    brand: 'Apple',
    category: 'laptops',
    store: 'amazon',
    price: price(114900, 124900),
    rating: { average: 4.8, count: 6421 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/macbook-air-m3.jpg',
    description: 'M3 chip, 18-hour battery life, Liquid Retina display.',
    attributes: { ram: '8GB', storage: '256GB SSD', color: 'Midnight' },
    productUrl: 'https://www.amazon.in/dp/mock-p005',
  },
  {
    id: 'p006',
    slug: 'dell-xps-13-i7-512gb',
    title: 'Dell XPS 13 (i7, 512GB SSD)',
    brand: 'Dell',
    category: 'laptops',
    store: 'flipkart',
    price: price(119990, 139990),
    rating: { average: 4.5, count: 2210 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 4,
    image: '/products/dell-xps-13.jpg',
    description: 'InfinityEdge display, 13th Gen Intel Core i7, compact chassis.',
    attributes: { ram: '16GB', storage: '512GB SSD', cpu: 'Intel i7-1355U' },
    productUrl: 'https://www.flipkart.com/mock-p006',
  },
  {
    id: 'p007',
    slug: 'hp-pavilion-14-ryzen-7',
    title: 'HP Pavilion 14 (Ryzen 7, 512GB SSD)',
    brand: 'HP',
    category: 'laptops',
    store: 'croma',
    price: price(64999, 74999),
    rating: { average: 4.3, count: 1890 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/hp-pavilion-14.jpg',
    description: 'AMD Ryzen 7 7730U, 16GB RAM, backlit keyboard.',
    attributes: { ram: '16GB', storage: '512GB SSD', cpu: 'Ryzen 7 7730U' },
    productUrl: 'https://www.croma.com/mock-p007',
  },
  {
    id: 'p008',
    slug: 'lenovo-legion-5-rtx4060',
    title: 'Lenovo Legion 5 (RTX 4060, 16GB)',
    brand: 'Lenovo',
    category: 'laptops',
    store: 'vijay_sales',
    price: price(94990, 109990),
    rating: { average: 4.6, count: 980 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/lenovo-legion-5.jpg',
    description: '144Hz display, RTX 4060, Ryzen 7 7840HS gaming laptop.',
    attributes: { ram: '16GB', storage: '1TB SSD', gpu: 'RTX 4060' },
    productUrl: 'https://www.vijaysales.com/mock-p008',
  },
  {
    id: 'p009',
    slug: 'asus-rog-zephyrus-g14',
    title: 'ASUS ROG Zephyrus G14 (RTX 4070)',
    brand: 'ASUS',
    category: 'laptops',
    store: 'reliance_digital',
    price: price(154990, 174990),
    rating: { average: 4.7, count: 640 },
    stockStatus: 'limited',
    deliveryEtaDays: 6,
    image: '/products/asus-rog-zephyrus-g14.jpg',
    description: 'Ryzen 9 8945HS, RTX 4070, 2K 165Hz display.',
    attributes: { ram: '32GB', storage: '1TB SSD', gpu: 'RTX 4070' },
    productUrl: 'https://www.reliancedigital.in/mock-p009',
  },
  {
    id: 'p010',
    slug: 'sony-wh-1000xm5-black',
    title: 'Sony WH-1000XM5 Wireless Headphones - Black',
    brand: 'Sony',
    category: 'audio',
    store: 'amazon',
    price: price(26990, 34990),
    rating: { average: 4.7, count: 14203 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/sony-wh1000xm5-black.jpg',
    description: 'Industry-leading noise cancellation, 30-hour battery.',
    attributes: { color: 'Black', type: 'Over-ear', battery: '30hrs' },
    productUrl: 'https://www.amazon.in/dp/mock-p010',
  },
  {
    id: 'p011',
    slug: 'boat-airdopes-441-pro',
    title: 'boAt Airdopes 441 Pro TWS Earbuds',
    brand: 'boAt',
    category: 'audio',
    store: 'flipkart',
    price: price(1499, 4990),
    rating: { average: 4.1, count: 28110 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/boat-airdopes-441-pro.jpg',
    description: 'ENx tech, ANC, 42H playback, IPX4 water resistance.',
    attributes: { color: 'Black', type: 'In-ear', battery: '42hrs (case)' },
    productUrl: 'https://www.flipkart.com/mock-p011',
  },
  {
    id: 'p012',
    slug: 'jbl-flip-6-portable-speaker',
    title: 'JBL Flip 6 Portable Bluetooth Speaker',
    brand: 'JBL',
    category: 'audio',
    store: 'croma',
    price: price(9999, 12999),
    rating: { average: 4.6, count: 5410 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/jbl-flip-6.jpg',
    description: 'IP67 waterproof, punchy JBL Pro Sound, 12-hour playtime.',
    attributes: { color: 'Blue', type: 'Portable', battery: '12hrs' },
    productUrl: 'https://www.croma.com/mock-p012',
  },
  {
    id: 'p013',
    slug: 'bose-quietcomfort-ultra',
    title: 'Bose QuietComfort Ultra Headphones',
    brand: 'Bose',
    category: 'audio',
    store: 'reliance_digital',
    price: price(34900, 37900),
    rating: { average: 4.6, count: 1120 },
    stockStatus: 'limited',
    deliveryEtaDays: 4,
    image: '/products/bose-qc-ultra.jpg',
    description: 'Immersive Audio, best-in-class ANC, plush comfort.',
    attributes: { color: 'Black', type: 'Over-ear', battery: '24hrs' },
    productUrl: 'https://www.reliancedigital.in/mock-p013',
  },
  {
    id: 'p014',
    slug: 'sony-bravia-55-4k-google-tv',
    title: 'Sony Bravia 55" 4K Google TV',
    brand: 'Sony',
    category: 'televisions',
    store: 'vijay_sales',
    price: price(74990, 94990),
    rating: { average: 4.5, count: 2310 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/sony-bravia-55.jpg',
    description: '4K HDR, Google TV, X1 processor, Dolby Vision & Atmos.',
    attributes: { size: '55"', resolution: '4K UHD', panel: 'LED' },
    productUrl: 'https://www.vijaysales.com/mock-p014',
  },
  {
    id: 'p015',
    slug: 'samsung-crystal-4k-50-uhd',
    title: 'Samsung Crystal 4K 50" UHD Smart TV',
    brand: 'Samsung',
    category: 'televisions',
    store: 'amazon',
    price: price(38990, 49990),
    rating: { average: 4.4, count: 8930 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/samsung-crystal-4k-50.jpg',
    description: 'Crystal Processor 4K, PurColor, Tizen smart platform.',
    attributes: { size: '50"', resolution: '4K UHD', panel: 'LED' },
    productUrl: 'https://www.amazon.in/dp/mock-p015',
  },
  {
    id: 'p016',
    slug: 'lg-oled-c3-65',
    title: 'LG OLED C3 65" 4K Smart TV',
    brand: 'LG',
    category: 'televisions',
    store: 'croma',
    price: price(189990, 229990),
    rating: { average: 4.8, count: 740 },
    stockStatus: 'limited',
    deliveryEtaDays: 6,
    image: '/products/lg-oled-c3-65.jpg',
    description: 'Self-lit OLED pixels, a9 Gen6 AI Processor, webOS.',
    attributes: { size: '65"', resolution: '4K OLED', panel: 'OLED' },
    productUrl: 'https://www.croma.com/mock-p016',
  },
  {
    id: 'p017',
    slug: 'mi-led-tv-x-pro-43',
    title: 'Mi LED TV X Pro 43" 4K',
    brand: 'Xiaomi',
    category: 'televisions',
    store: 'flipkart',
    price: price(26999, 34999),
    rating: { average: 4.2, count: 6210 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/mi-tv-x-pro-43.jpg',
    description: 'Dolby Vision, Android TV, 30W speakers.',
    attributes: { size: '43"', resolution: '4K UHD', panel: 'LED' },
    productUrl: 'https://www.flipkart.com/mock-p017',
  },
  {
    id: 'p018',
    slug: 'apple-watch-series-9-45mm',
    title: 'Apple Watch Series 9 (45mm GPS)',
    brand: 'Apple',
    category: 'wearables',
    store: 'amazon',
    price: price(41900, 45900),
    rating: { average: 4.7, count: 5320 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/apple-watch-series-9.jpg',
    description: 'S9 SiP, Double Tap gesture, Always-On Retina display.',
    attributes: { size: '45mm', color: 'Midnight', battery: '18hrs' },
    productUrl: 'https://www.amazon.in/dp/mock-p018',
  },
  {
    id: 'p019',
    slug: 'samsung-galaxy-watch-6-44mm',
    title: 'Samsung Galaxy Watch 6 (44mm)',
    brand: 'Samsung',
    category: 'wearables',
    store: 'flipkart',
    price: price(28999, 34999),
    rating: { average: 4.4, count: 3110 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/galaxy-watch-6.jpg',
    description: 'Sapphire crystal glass, advanced sleep coaching, BIA sensor.',
    attributes: { size: '44mm', color: 'Graphite', battery: '40hrs' },
    productUrl: 'https://www.flipkart.com/mock-p019',
  },
  {
    id: 'p020',
    slug: 'noise-colorfit-pro-4',
    title: 'Noise ColorFit Pro 4 Smartwatch',
    brand: 'Noise',
    category: 'wearables',
    store: 'croma',
    price: price(2499, 5999),
    rating: { average: 4.0, count: 9870 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/noise-colorfit-pro-4.jpg',
    description: 'Bluetooth calling, 1.8" HD display, 7-day battery.',
    attributes: { size: '1.8"', color: 'Jet Black', battery: '7 days' },
    productUrl: 'https://www.croma.com/mock-p020',
  },
  {
    id: 'p021',
    slug: 'fitbit-charge-6',
    title: 'Fitbit Charge 6 Fitness Tracker',
    brand: 'Fitbit',
    category: 'wearables',
    store: 'reliance_digital',
    price: price(15999, 18999),
    rating: { average: 4.3, count: 1420 },
    stockStatus: 'limited',
    deliveryEtaDays: 4,
    image: '/products/fitbit-charge-6.jpg',
    description: 'Built-in GPS, heart rate tracking, 7-day battery life.',
    attributes: { color: 'Black', battery: '7 days' },
    productUrl: 'https://www.reliancedigital.in/mock-p021',
  },
  {
    id: 'p022',
    slug: 'lg-double-door-refrigerator-260l',
    title: 'LG 260L Double Door Refrigerator',
    brand: 'LG',
    category: 'home_appliances',
    store: 'vijay_sales',
    price: price(28990, 34990),
    rating: { average: 4.4, count: 2870 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/lg-refrigerator-260l.jpg',
    description: 'Smart Inverter Compressor, toughened glass shelves, 3-star rating.',
    attributes: { capacity: '260L', energyRating: '3 Star', type: 'Double Door' },
    productUrl: 'https://www.vijaysales.com/mock-p022',
  },
  {
    id: 'p023',
    slug: 'samsung-front-load-washing-machine-7kg',
    title: 'Samsung 7kg Front Load Washing Machine',
    brand: 'Samsung',
    category: 'home_appliances',
    store: 'croma',
    price: price(31990, 38990),
    rating: { average: 4.5, count: 1980 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/samsung-washing-machine-7kg.jpg',
    description: 'Ecobubble technology, digital inverter motor, 5-star rating.',
    attributes: { capacity: '7kg', energyRating: '5 Star', type: 'Front Load' },
    productUrl: 'https://www.croma.com/mock-p023',
  },
  {
    id: 'p024',
    slug: 'voltas-1-5-ton-split-ac',
    title: 'Voltas 1.5 Ton Split AC (5 Star)',
    brand: 'Voltas',
    category: 'home_appliances',
    store: 'reliance_digital',
    price: price(33990, 42990),
    rating: { average: 4.3, count: 4210 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 6,
    image: '/products/voltas-1-5-ton-ac.jpg',
    description: 'Copper condenser, adjustable mode, anti-dust filter.',
    attributes: { capacity: '1.5 Ton', energyRating: '5 Star', type: 'Split AC' },
    productUrl: 'https://www.reliancedigital.in/mock-p024',
  },
  {
    id: 'p025',
    slug: 'philips-air-fryer-hd9252',
    title: 'Philips Air Fryer HD9252 (4.1L)',
    brand: 'Philips',
    category: 'home_appliances',
    store: 'amazon',
    price: price(7995, 10995),
    rating: { average: 4.5, count: 12430 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/philips-air-fryer.jpg',
    description: 'Rapid Air technology, 90% less fat, digital display.',
    attributes: { capacity: '4.1L', power: '1400W' },
    productUrl: 'https://www.amazon.in/dp/mock-p025',
  },
  {
    id: 'p026',
    slug: 'prestige-mixer-grinder-750w',
    title: 'Prestige Mixer Grinder 750W',
    brand: 'Prestige',
    category: 'home_appliances',
    store: 'flipkart',
    price: price(3299, 4495),
    rating: { average: 4.2, count: 7650 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 3,
    image: '/products/prestige-mixer-grinder.jpg',
    description: '3 stainless steel jars, powerful motor, 5-year warranty.',
    attributes: { power: '750W', jars: '3' },
    productUrl: 'https://www.flipkart.com/mock-p026',
  },
  {
    id: 'p027',
    slug: 'canon-eos-r10-mirrorless',
    title: 'Canon EOS R10 Mirrorless Camera (Body)',
    brand: 'Canon',
    category: 'cameras',
    store: 'croma',
    price: price(84999, 94999),
    rating: { average: 4.6, count: 540 },
    stockStatus: 'limited',
    deliveryEtaDays: 6,
    image: '/products/canon-eos-r10.jpg',
    description: '24.2MP APS-C sensor, 4K video, fast Dual Pixel AF.',
    attributes: { sensor: 'APS-C', resolution: '24.2MP', video: '4K' },
    productUrl: 'https://www.croma.com/mock-p027',
  },
  {
    id: 'p028',
    slug: 'sony-alpha-a6400-mirrorless',
    title: 'Sony Alpha a6400 Mirrorless Camera (Body)',
    brand: 'Sony',
    category: 'cameras',
    store: 'vijay_sales',
    price: price(79990, 89990),
    rating: { average: 4.7, count: 890 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/sony-alpha-a6400.jpg',
    description: 'Real-time Eye AF, 0.02s autofocus, 4K HDR video.',
    attributes: { sensor: 'APS-C', resolution: '24.2MP', video: '4K' },
    productUrl: 'https://www.vijaysales.com/mock-p028',
  },
  {
    id: 'p029',
    slug: 'gopro-hero-12-black',
    title: 'GoPro HERO12 Black Action Camera',
    brand: 'GoPro',
    category: 'cameras',
    store: 'amazon',
    price: price(41500, 46500),
    rating: { average: 4.5, count: 2340 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 2,
    image: '/products/gopro-hero12-black.jpg',
    description: '5.3K video, HyperSmooth 6.0 stabilization, waterproof to 10m.',
    attributes: { resolution: '5.3K', waterproof: '10m', battery: 'Enduro' },
    productUrl: 'https://www.amazon.in/dp/mock-p029',
  },
  {
    id: 'p030',
    slug: 'nikon-z50-mirrorless-kit',
    title: 'Nikon Z50 Mirrorless Camera (with 16-50mm Kit Lens)',
    brand: 'Nikon',
    category: 'cameras',
    store: 'reliance_digital',
    price: price(72990, 84990),
    rating: { average: 4.4, count: 610 },
    stockStatus: 'in_stock',
    deliveryEtaDays: 5,
    image: '/products/nikon-z50-kit.jpg',
    description: 'DX-format CMOS sensor, 209-point AF, compact mirrorless body.',
    attributes: { sensor: 'APS-C', resolution: '20.9MP', video: '4K' },
    productUrl: 'https://www.reliancedigital.in/mock-p030',
  },
];

/**
 * Case-insensitive substring search across title, brand, and description.
 * Mirrors the intent of `GET /v1/search?q=` (docs/api.md §2.1) at a
 * mock-data level — no ranking/relevance scoring, just a match filter.
 */
export function searchProducts(query: string, source: Product[] = PRODUCTS): Product[] {
  const q = query.trim().toLowerCase();
  if (!q) return source;
  return source.filter((p) =>
    [p.title, p.brand, p.description].some((field) => field.toLowerCase().includes(q))
  );
}

/**
 * Applies category, store, price-range, and rating filters.
 * Combines with searchProducts() via `filters.query` for a single entry point.
 */
export function filterProducts(filters: SearchFilters, source: Product[] = PRODUCTS): Product[] {
  let result = filters.query ? searchProducts(filters.query, source) : [...source];

  if (filters.category) {
    result = result.filter((p) => p.category === filters.category);
  }

  if (filters.stores && filters.stores.length > 0) {
    result = result.filter((p) => filters.stores!.includes(p.store));
  }

  if (typeof filters.minPrice === 'number') {
    result = result.filter((p) => p.price.current >= filters.minPrice!);
  }

  if (typeof filters.maxPrice === 'number') {
    result = result.filter((p) => p.price.current <= filters.maxPrice!);
  }

  if (typeof filters.minRating === 'number') {
    result = result.filter((p) => p.rating.average >= filters.minRating!);
  }

  if (filters.sort) {
    result = sortProducts(result, filters.sort);
  }

  return result;
}

/**
 * Sorts a product list. `relevance` is a no-op here (order-preserving)
 * since no scoring model exists at the mock-data layer yet — real
 * relevance ranking is Search Orchestrator/Ranking scope (search-engine.md §2.8).
 */
export function sortProducts(products: Product[], sort: SearchSortOption): Product[] {
  const sorted = [...products];

  switch (sort) {
    case 'price_asc':
      return sorted.sort((a, b) => a.price.current - b.price.current);
    case 'price_desc':
      return sorted.sort((a, b) => b.price.current - a.price.current);
    case 'rating':
      return sorted.sort((a, b) => b.rating.average - a.rating.average);
    case 'relevance':
    default:
      return sorted;
  }
}

export function getProductById(id: string, source: Product[] = PRODUCTS): Product | undefined {
  return source.find((p) => p.id === id);
}

/** Convenience wrapper returning a SearchResult envelope (items + total). */
export function runSearch(filters: SearchFilters): SearchResult<Product> {
  const items = filterProducts(filters);
  return { items, total: items.length };
}
