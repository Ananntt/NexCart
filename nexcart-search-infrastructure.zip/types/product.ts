import type { StoreSlug } from './store';

/**
 * Frontend-only mock product model (lib/products.ts).
 *
 * This deliberately mirrors the *shape* of the canonical Products/Offers
 * pair described in docs/database.md §6/§10, flattened into one object
 * for simplicity, since there is no backend/DB yet (Sprint 6.1 excludes
 * DB work). Once real Products/Offers land, this type should be treated
 * as a UI-facing view model, not the source of truth.
 */

export type ProductCategorySlug =
  | 'mobiles'
  | 'laptops'
  | 'audio'
  | 'televisions'
  | 'wearables'
  | 'home_appliances'
  | 'cameras';

export type StockStatus = 'in_stock' | 'out_of_stock' | 'limited';

export interface ProductRating {
  average: number; // 0–5
  count: number;
}

export interface ProductPrice {
  /** Current selling price (INR). */
  current: number;
  /** List / MRP price (INR). */
  mrp: number;
  /** Derived discount percentage, rounded. */
  discountPercent: number;
  currency: 'INR';
}

export interface Product {
  id: string;
  slug: string;
  title: string;
  brand: string;
  category: ProductCategorySlug;
  store: StoreSlug;
  price: ProductPrice;
  rating: ProductRating;
  stockStatus: StockStatus;
  /** Delivery estimate in days, store-dependent. */
  deliveryEtaDays: number;
  image: string;
  description: string;
  /** Free-form specs, e.g. { ram: "8GB", storage: "128GB" } */
  attributes: Record<string, string>;
  /** Deep link / affiliate link placeholder. */
  productUrl: string;
}
