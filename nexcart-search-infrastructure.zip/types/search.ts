import type { ProductCategorySlug } from './product';
import type { StoreSlug } from './store';

/**
 * Search-facing types consumed by lib/products.ts helpers.
 *
 * These are UI/mock-data-layer types only. They intentionally align in
 * spirit with the query params documented for `GET /v1/search` in
 * docs/api.md §2.1, so swapping this mock layer for the real endpoint
 * later is a drop-in replacement rather than a redesign.
 */

export type SearchSortOption =
  | 'relevance'
  | 'price_asc'
  | 'price_desc'
  | 'rating';

export interface SearchFilters {
  query?: string;
  category?: ProductCategorySlug;
  stores?: StoreSlug[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  sort?: SearchSortOption;
}

export interface SearchResult<T> {
  items: T[];
  total: number;
}
