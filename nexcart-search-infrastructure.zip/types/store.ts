/**
 * Store / Provider-facing types.
 *
 * NOTE: This is a lightweight, frontend-only representation used by the
 * mock product dataset (lib/products.ts). It intentionally does NOT model
 * the full `Providers` collection described in docs/database.md §7 —
 * that is backend/DB scope (Sprint 6.2+, src/db/). This type only exists
 * to label which storefront a mock product/offer "came from" for UI
 * purposes ahead of real provider integration.
 */

export type StoreSlug =
  | 'amazon'
  | 'flipkart'
  | 'croma'
  | 'reliance_digital'
  | 'vijay_sales';

export interface StoreInfo {
  slug: StoreSlug;
  name: string;
  /** Path under /public, or an external logo URL — resolved by the UI layer. */
  logo: string;
  /** Brand accent color (hex), used for badges/chips in the UI. */
  color: string;
}

export const STORES: Record<StoreSlug, StoreInfo> = {
  amazon: {
    slug: 'amazon',
    name: 'Amazon',
    logo: '/stores/amazon.svg',
    color: '#FF9900',
  },
  flipkart: {
    slug: 'flipkart',
    name: 'Flipkart',
    logo: '/stores/flipkart.svg',
    color: '#2874F0',
  },
  croma: {
    slug: 'croma',
    name: 'Croma',
    logo: '/stores/croma.svg',
    color: '#00A19C',
  },
  reliance_digital: {
    slug: 'reliance_digital',
    name: 'Reliance Digital',
    logo: '/stores/reliance-digital.svg',
    color: '#E4002B',
  },
  vijay_sales: {
    slug: 'vijay_sales',
    name: 'Vijay Sales',
    logo: '/stores/vijay-sales.svg',
    color: '#004C97',
  },
};
