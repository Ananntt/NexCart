/**
 * GET /v1/search — Sprint 6.1 stub only (api.md §2.1). Validates input
 * and returns a correctly-shaped, empty response. Does NOT call
 * Search/Providers/DB/Services — none of that exists yet, and wiring it
 * in is explicitly out of scope for this sprint.
 */

import { NextRequest } from 'next/server';
import { successResponse, errorResponse } from '@/src/server/http/response';
import { validateSearchQuery } from '@/src/server/http/validation';
import { beginRequestLog } from '@/src/server/middleware/request-logging';

export async function GET(request: NextRequest) {
  const requestLog = beginRequestLog(request, 'GET /v1/search');

  try {
    const query = validateSearchQuery(request.nextUrl.searchParams);

    requestLog.logger.debug('validated search query', { query });

    // Stub response — Search Orchestrator / Search Service wiring lands
    // in a later sprint (search-engine.md §2.4 onward).
    const response = successResponse([], {
      meta: { page: query.page, limit: query.limit, total: 0 },
    });

    requestLog.finish(200);
    return response;
  } catch (error) {
    const response = errorResponse(error);
    requestLog.finish(response.status);
    return response;
  }
}
