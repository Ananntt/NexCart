/**
 * Reusable, framework-agnostic request-shape validators. Each returns a
 * boolean/type-guard — they never throw and never know about HTTP.
 * `src/server/http/validation.ts` composes these into route-level
 * parsing that does throw a domain error.
 */

const OBJECT_ID_RE = /^[a-f0-9]{24}$/i;

export function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

export function isStringWithLength(value: unknown, min: number, max: number): value is string {
  return typeof value === 'string' && value.length >= min && value.length <= max;
}

export function isValidObjectIdFormat(value: unknown): value is string {
  return typeof value === 'string' && OBJECT_ID_RE.test(value);
}

export function isOneOf<T extends string>(value: unknown, allowed: readonly T[]): value is T {
  return typeof value === 'string' && (allowed as readonly string[]).includes(value);
}

export function isNonNegativeNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0;
}

/**
 * Parses a query-string value into a number.
 * Returns `undefined` if the param was absent/blank, `NaN` if present but
 * not a valid number — callers distinguish "missing" from "malformed".
 */
export function parseOptionalNumber(value: string | null): number | undefined {
  if (value === null || value.trim() === '') return undefined;
  const n = Number(value);
  return Number.isFinite(n) ? n : NaN;
}
