/**
 * Shared error-code constants (api.md §10: "one shared enum/constants
 * file across the API surface, so frontend error handling can switch on
 * error.code rather than parsing message strings").
 *
 * Only generic, cross-cutting codes live here. Endpoint-specific codes
 * (e.g. EMAIL_TAKEN, DUPLICATE_REVIEW, ALREADY_FAVORITED) are added
 * alongside the feature/sprint that introduces them — not invented here
 * ahead of time.
 */

export const ERROR_CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_PRICE_RANGE: 'INVALID_PRICE_RANGE',
  NOT_FOUND: 'NOT_FOUND',
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
} as const;

export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];
