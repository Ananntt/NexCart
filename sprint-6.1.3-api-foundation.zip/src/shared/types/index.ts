/**
 * Generic, framework-agnostic type primitives shared across the whole
 * backend. Nothing here is tied to a specific feature, layer, or library.
 *
 * Intentionally excluded: the Result<T, E> pattern itself, which has its
 * own runtime helpers (ok/err/isOk/isErr) and lives in `src/shared/result/`
 * instead of being a plain type alias here.
 */

/** A value that may be null (but is always present, unlike Optional). */
export type Nullable<T> = T | null;

/** A value that may be omitted entirely (but is never null, unlike Nullable). */
export type Optional<T> = T | undefined;

/** A value that may be missing or null. */
export type Maybe<T> = T | null | undefined;

/** The set of JavaScript primitive value types. */
export type Primitive = string | number | boolean | null | undefined;

/** Any value representable in JSON. */
export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

/** A JSON value that is specifically an object (not an array or scalar). */
export type JsonObject = { [key: string]: JsonValue };

/**
 * ISO 8601 timestamp string. Used everywhere a date crosses a JSON
 * boundary (API responses, logs) instead of a native Date instance.
 */
export type Timestamp = string;

/**
 * Per-request metadata threaded through the HTTP layer and, later, into
 * Services/Search for correlation. Constructed in
 * `src/server/context/request-context.ts` — this file only defines the
 * shape, so any layer can depend on the type without depending on how
 * it's built.
 */
export interface RequestContext {
  /** Unique id generated for this request, present on every request. */
  readonly requestId: string;
  /** Optional distributed-trace id, propagated if the caller supplied one. */
  readonly traceId?: string;
  /** High-resolution start time (ms, from Date.now()) — used for duration logging. */
  readonly startTime: number;
}
