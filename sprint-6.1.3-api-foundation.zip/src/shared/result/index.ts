/**
 * Result<T, E> — the standard return shape for Services and Search-layer
 * functions (architecture-freeze-v1.md §6). Expected failure modes
 * (validation, not-found, provider timeout) are values, not throws;
 * exceptions stay reserved for truly unexpected errors.
 *
 * This module has no Services/Search consumers yet in Sprint 6.1 — it's
 * built now because it's a Shared-layer primitive with zero dependencies
 * (config or otherwise), and `src/shared/types/index.ts` already noted
 * it as deliberately deferred out of the previous shared-foundation pass.
 */

export interface Ok<T> {
  readonly success: true;
  readonly data: T;
}

export interface Err<E> {
  readonly success: false;
  readonly error: E;
}

export type Result<T, E> = Ok<T> | Err<E>;

export function ok<T>(data: T): Ok<T> {
  return { success: true, data };
}

export function err<E>(error: E): Err<E> {
  return { success: false, error };
}

export function isOk<T, E>(result: Result<T, E>): result is Ok<T> {
  return result.success;
}

export function isErr<T, E>(result: Result<T, E>): result is Err<E> {
  return !result.success;
}

/** Unwraps a Result, throwing if it's an Err. Use sparingly — mainly in tests. */
export function unwrap<T, E>(result: Result<T, E>): T {
  if (isErr(result)) {
    throw new Error(`Called unwrap on an Err result: ${JSON.stringify(result.error)}`);
  }
  return result.data;
}
