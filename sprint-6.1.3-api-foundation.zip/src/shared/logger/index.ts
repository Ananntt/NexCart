/**
 * Structured logger — every layer logs through this, never directly to
 * stdout (architecture-freeze-v1.md §6). Deliberately does NOT read
 * process.env itself: log level / transport wiring is Config's
 * responsibility once `src/config/` lands. Until then this defaults to
 * a sane level ('info') and a single console transport, so nothing here
 * needs to change when Config is integrated later — a caller will be
 * able to pass `{ level: config.logLevel }` without touching this file.
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_WEIGHT: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

/**
 * Deliberately `Record<string, unknown>` rather than the stricter
 * `JsonObject` — callers frequently pass typed request/query objects
 * with optional (possibly-undefined) properties, and this is a logging
 * sink (JSON.stringify drops undefined values fine), not a wire
 * contract that needs JsonValue's strictness.
 */
export type LogFields = Record<string, unknown>;

export interface LoggerOptions {
  /** Minimum level that gets emitted. Defaults to 'info'. */
  level?: LogLevel;
  /** Correlation fields (e.g. requestId/traceId) attached to every entry from this logger instance. */
  context?: LogFields;
}

export interface Logger {
  debug(message: string, fields?: LogFields): void;
  info(message: string, fields?: LogFields): void;
  warn(message: string, fields?: LogFields): void;
  error(message: string, fields?: LogFields): void;
  /** Returns a new Logger with additional context fields merged in (e.g. requestId). */
  child(context: LogFields): Logger;
}

export function createLogger(options: LoggerOptions = {}): Logger {
  const level = options.level ?? 'info';
  const context = options.context ?? {};

  function emit(entryLevel: LogLevel, message: string, fields?: LogFields): void {
    if (LEVEL_WEIGHT[entryLevel] < LEVEL_WEIGHT[level]) return;

    const entry = {
      level: entryLevel,
      message,
      timestamp: new Date().toISOString(),
      ...context,
      ...fields,
    };

    const line = JSON.stringify(entry);
    if (entryLevel === 'error') {
      console.error(line);
    } else if (entryLevel === 'warn') {
      console.warn(line);
    } else {
      console.log(line);
    }
  }

  return {
    debug: (message, fields) => emit('debug', message, fields),
    info: (message, fields) => emit('info', message, fields),
    warn: (message, fields) => emit('warn', message, fields),
    error: (message, fields) => emit('error', message, fields),
    child: (childContext) => createLogger({ level, context: { ...context, ...childContext } }),
  };
}

/** Root application logger. Server code derives a per-request child via `.child({ requestId })`. */
export const logger: Logger = createLogger();
