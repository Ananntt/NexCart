/**
 * Public entry point for the Shared Foundation layer.
 * Every consumer imports from `@/src/shared`, never from
 * `@/src/shared/types`, `@/src/shared/utils`, `@/src/shared/result`,
 * `@/src/shared/logger`, or `@/src/shared/constants` directly.
 */

export type {
  Nullable,
  Optional,
  Maybe,
  Primitive,
  JsonValue,
  JsonObject,
  Timestamp,
  RequestContext,
} from './types';

export {
  assert,
  isDefined,
  isNullish,
  assertNever,
  nowIso,
  addMs,
  addSeconds,
  addMinutes,
  isPast,
  isFuture,
  msBetween,
} from './utils';

export type { Result, Ok, Err } from './result';
export { ok, err, isOk, isErr, unwrap } from './result';

export type { Logger, LogLevel, LogFields, LoggerOptions } from './logger';
export { logger, createLogger } from './logger';

export { ERROR_CODES } from './constants';
export type { ErrorCode } from './constants';
