/**
 * Domain error class hierarchy. These are plain, framework-agnostic
 * errors — validation helpers (and, later, Services) throw these
 * without knowing anything about HTTP. Mapping to an HTTP status +
 * envelope happens in `error-mapper.ts`, never here.
 *
 * Only the error classes needed for Sprint 6.1 (validation, invalid
 * range, not-found, rate-limit, internal) are defined. Auth-specific
 * errors (UnauthorizedError, ForbiddenError) and business-specific ones
 * (e.g. DuplicateReviewError) are added when those features land —
 * inventing them now would be assuming shape for logic that doesn't
 * exist yet.
 */

import { ERROR_CODES, type ErrorCode } from '../../shared/constants';

export interface ValidationIssue {
  field: string;
  issue: string;
}

export abstract class AppError extends Error {
  abstract readonly code: ErrorCode;

  constructor(message: string) {
    super(message);
    this.name = new.target.name;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

/** 400 — malformed/missing input (api.md §0.5). */
export class ValidationError extends AppError {
  readonly code = ERROR_CODES.VALIDATION_ERROR;
  readonly details: ValidationIssue[];

  constructor(message: string, details: ValidationIssue[] = []) {
    super(message);
    this.details = details;
  }
}

/** 422 — semantically invalid input, e.g. maxPrice < minPrice (api.md §0.5, §2.1). */
export class InvalidRangeError extends AppError {
  readonly code = ERROR_CODES.INVALID_PRICE_RANGE;

  constructor(message = 'Invalid range') {
    super(message);
  }
}

/** 404 (api.md §0.5). */
export class NotFoundError extends AppError {
  readonly code = ERROR_CODES.NOT_FOUND;

  constructor(message = 'Resource not found') {
    super(message);
  }
}

/** 429 (api.md §0.5/§0.6). */
export class RateLimitError extends AppError {
  readonly code = ERROR_CODES.RATE_LIMIT_EXCEEDED;
  readonly retryAfterSeconds?: number;

  constructor(message = 'Rate limit exceeded', retryAfterSeconds?: number) {
    super(message);
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

/** 500 (api.md §0.5) — used for genuinely unexpected failures. */
export class InternalError extends AppError {
  readonly code = ERROR_CODES.INTERNAL_ERROR;

  constructor(message = 'Internal server error') {
    super(message);
  }
}
