/**
 * HTTP-level validation glue: reads a request's search params, validates
 * them with `src/validation` primitives, and throws the appropriate
 * domain error (ValidationError / InvalidRangeError, api.md §0.4/§0.5)
 * on failure. Route handlers call these instead of validating inline.
 */

import { ValidationError, InvalidRangeError, type ValidationIssue } from '../errors/errors';
import {
  isNonEmptyString,
  isStringWithLength,
  isOneOf,
  parseOptionalNumber,
} from '../../validation/validators';

export interface SearchQueryInput {
  q: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  providers?: string[];
  sort: 'relevance' | 'price_asc' | 'price_desc' | 'rating';
  page: number;
  limit: number;
}

const SORT_VALUES = ['relevance', 'price_asc', 'price_desc', 'rating'] as const;

/**
 * Validates `GET /v1/search` query params per api.md §2.1. This is a
 * stub-sprint validator: it enforces shape/range only. It does not, and
 * must not, call Search/Providers/DB.
 */
export function validateSearchQuery(searchParams: URLSearchParams): SearchQueryInput {
  const issues: ValidationIssue[] = [];

  const qRaw = searchParams.get('q');
  const q = qRaw?.trim() ?? '';
  if (!isNonEmptyString(q) || !isStringWithLength(q, 1, 200)) {
    issues.push({ field: 'q', issue: 'required, 1-200 characters' });
  }

  const category = searchParams.get('category') ?? undefined;

  const minPriceRaw = parseOptionalNumber(searchParams.get('minPrice'));
  if (minPriceRaw !== undefined && (Number.isNaN(minPriceRaw) || minPriceRaw < 0)) {
    issues.push({ field: 'minPrice', issue: 'must be a number >= 0' });
  }

  const maxPriceRaw = parseOptionalNumber(searchParams.get('maxPrice'));
  if (maxPriceRaw !== undefined && (Number.isNaN(maxPriceRaw) || maxPriceRaw < 0)) {
    issues.push({ field: 'maxPrice', issue: 'must be a number >= 0' });
  }

  const providersRaw = searchParams.get('providers');
  const providers = providersRaw
    ? providersRaw.split(',').map((p) => p.trim()).filter(Boolean)
    : undefined;

  const sortRaw = searchParams.get('sort') ?? 'relevance';
  if (!isOneOf(sortRaw, SORT_VALUES)) {
    issues.push({ field: 'sort', issue: `must be one of: ${SORT_VALUES.join(', ')}` });
  }

  const pageRaw = parseOptionalNumber(searchParams.get('page')) ?? 1;
  const page = Number.isNaN(pageRaw) || pageRaw < 1 ? 1 : Math.floor(pageRaw);

  const limitRaw = parseOptionalNumber(searchParams.get('limit')) ?? 20;
  const limit = Number.isNaN(limitRaw) ? 20 : Math.min(Math.max(Math.floor(limitRaw), 1), 100);

  if (issues.length > 0) {
    throw new ValidationError('Invalid search query', issues);
  }

  // Semantic (422) check, kept separate from shape (400) checks per api.md §0.5/§2.1.
  const minPrice = typeof minPriceRaw === 'number' && !Number.isNaN(minPriceRaw) ? minPriceRaw : undefined;
  const maxPrice = typeof maxPriceRaw === 'number' && !Number.isNaN(maxPriceRaw) ? maxPriceRaw : undefined;
  if (minPrice !== undefined && maxPrice !== undefined && minPrice > maxPrice) {
    throw new InvalidRangeError('minPrice must not exceed maxPrice');
  }

  return {
    q,
    category,
    minPrice,
    maxPrice,
    providers,
    sort: sortRaw as SearchQueryInput['sort'],
    page,
    limit,
  };
}
