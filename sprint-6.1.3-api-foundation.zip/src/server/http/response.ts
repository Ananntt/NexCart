/**
 * Standard response envelope builders (api.md §0.3 / §0.4). One place
 * that knows the envelope shape — no route hand-builds
 * `{ success, data }` itself.
 */

import { NextResponse } from 'next/server';
import { mapErrorToHttp } from '../errors/error-mapper';

export interface SuccessMeta {
  page?: number;
  limit?: number;
  total?: number;
}

export function successResponse<T>(
  data: T,
  init?: { status?: number; meta?: SuccessMeta }
): NextResponse {
  const body: Record<string, unknown> = { success: true, data };
  if (init?.meta) body.meta = init.meta;
  return NextResponse.json(body, { status: init?.status ?? 200 });
}

export function errorResponse(error: unknown): NextResponse {
  const mapped = mapErrorToHttp(error);

  const body = {
    success: false,
    error: {
      code: mapped.code,
      message: mapped.message,
      ...(mapped.details ? { details: mapped.details } : {}),
    },
  };

  const headers: Record<string, string> = {};
  if (mapped.retryAfterSeconds !== undefined) {
    headers['Retry-After'] = String(mapped.retryAfterSeconds);
  }

  return NextResponse.json(body, { status: mapped.status, headers });
}
