# Deferred — src/server/config/

Thin wrapper over `src/config/` for server-only values
(architecture-freeze-v1.md §4). Deferred until `src/config/env.ts`
exists — see `src/server/health/DEFERRED.md` for the same dependency.
