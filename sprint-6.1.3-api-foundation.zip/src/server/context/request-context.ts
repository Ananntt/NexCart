/**
 * RequestContext construction (architecture-freeze-v1.md §4). Generates
 * a requestId for every request, accepts/derives an optional traceId,
 * and stamps a start time for duration logging. Route handlers build
 * this first, before anything else.
 */

import type { RequestContext } from '../../shared/types';

export function createRequestContext(incomingTraceId?: string | null): RequestContext {
  return {
    requestId: crypto.randomUUID(),
    traceId: incomingTraceId ?? undefined,
    startTime: Date.now(),
  };
}

/** Reads a caller-supplied trace id from common header names, if present. */
export function extractTraceId(headers: Headers): string | undefined {
  return headers.get('x-trace-id') ?? headers.get('traceparent') ?? undefined;
}
