# Deferred — src/server/health/

Not built in this pass. `GET /v1/health` (architecture-freeze-v1.md §4)
needs `APP_VERSION` / `APP_BUILD` / environment from `src/config/env.ts`,
which does not exist in the repo yet (only CTO review notes for it do —
see `NexCart_Config_Review_Changes.zip`).

Building this now would mean inventing config shape that hasn't been
seen. Once `env.ts` is available, this folder gets:
- `health-service.ts` — uptime, version/build, environment, timestamp
- wired into `app/api/v1/health/route.ts`

No other Sprint 6.1 file depends on this folder, so nothing needs to
change elsewhere when it's added.
