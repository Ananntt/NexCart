/**
 * Request logging helper for Sprint 6.1. Scoped deliberately to
 * request-id + structured start/end logging only — NOT auth or rate
 * limiting. Those require identity resolution (auth) and per-identity
 * counters (api.md §0.6) that aren't built yet; they stay `[Reserved]`
 * in `src/server/middleware/` until their dependencies (auth, config)
 * land.
 *
 * This is also not Next.js edge `middleware.ts` (that file is itself
 * `[Reserved]`, architecture-freeze-v1.md §14) — it's a small helper a
 * route handler calls explicitly, so route handlers stay in control of
 * their own request lifecycle without introducing a global edge
 * dependency ahead of schedule.
 */

import { logger, type Logger } from '../../shared/logger';
import { createRequestContext, extractTraceId } from '../context/request-context';
import type { RequestContext } from '../../shared/types';

export interface RequestLogHandle {
  context: RequestContext;
  logger: Logger;
  finish(status: number): void;
}

/** Call at the top of a route handler; call `.finish(status)` right before returning the response. */
export function beginRequestLog(request: Request, routeName: string): RequestLogHandle {
  const context = createRequestContext(extractTraceId(request.headers));
  const scopedLogger = logger.child({
    requestId: context.requestId,
    traceId: context.traceId ?? null,
    route: routeName,
  });

  scopedLogger.info('request started', { method: request.method, url: request.url });

  return {
    context,
    logger: scopedLogger,
    finish(status: number) {
      scopedLogger.info('request finished', {
        status,
        durationMs: Date.now() - context.startTime,
      });
    },
  };
}
