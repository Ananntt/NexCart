/**
 * GET /v1/search — Sprint 6.1 stub (api.md §2.1). Refactored in Sprint
 * 6.1.4 to use the standard route-handler wrapper (createRouteHandler)
 * instead of manually building request logging and a try/catch —
 * behavior is unchanged, only the boilerplate is consolidated.
 */

import { successResponse } from '@/src/server/http/response';
import { validateSearchQuery } from '@/src/server/http/validation';
import { createRouteHandler } from '@/src/server/middleware/create-route-handler';

export const GET = createRouteHandler('GET /v1/search', async ({ request, logger }) => {
  const query = validateSearchQuery(request.nextUrl.searchParams);
  logger.debug('validated search query', { query });

  // Stub response — Search Orchestrator / Search Service wiring lands
  // in a later sprint (search-engine.md §2.4 onward).
  return successResponse([], {
    meta: { page: query.page, limit: query.limit, total: 0 },
  });
});
