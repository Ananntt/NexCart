/**
 * Generic, composable field-validation runner. A "rule" checks one
 * value and returns an issue (or nothing); `runValidation` collects
 * issues across many fields.
 *
 * `FieldIssue` is intentionally its own local type rather than importing
 * `ValidationIssue` from `src/server/errors/errors.ts` — this module
 * stays dependency-free of the Server layer (src/validation/ sits below
 * Server, per architecture-freeze-v1.md §9/§10). The two shapes are
 * structurally identical, so constructing a ValidationError from a
 * FieldIssue[] elsewhere requires no conversion.
 *
 * No endpoint-specific rules are defined here — those stay next to the
 * endpoint that needs them (e.g. `server/http/validation.ts`'s search
 * validator).
 */

export interface FieldIssue {
  field: string;
  issue: string;
}

export type FieldRule = () => FieldIssue | undefined;

export function runValidation(rules: FieldRule[]): FieldIssue[] {
  const issues: FieldIssue[] = [];
  for (const rule of rules) {
    const issue = rule();
    if (issue) issues.push(issue);
  }
  return issues;
}

/** Builds a single field rule from a predicate — `isValid()` returning false produces the given issue. */
export function fieldRule(field: string, isValid: () => boolean, issue: string): FieldRule {
  return () => (isValid() ? undefined : { field, issue });
}
