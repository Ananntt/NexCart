/**
 * Safe JSON helpers that never throw. Parsing returns the existing
 * Result<T, E> pattern (src/shared/result) instead of a new
 * success/failure shape.
 */

import { ok, err, type Result } from '../result';

export function safeJsonParse<T = unknown>(input: string): Result<T, Error> {
  try {
    return ok(JSON.parse(input) as T);
  } catch (error) {
    return err(error instanceof Error ? error : new Error('Invalid JSON'));
  }
}

/** Stringify that never throws (e.g. on circular references) — returns undefined instead. */
export function safeJsonStringify(value: unknown): string | undefined {
  try {
    return JSON.stringify(value);
  } catch {
    return undefined;
  }
}
