/**
 * Log transport abstraction. This is the only file that knows how a log
 * line is actually emitted (currently: console). Swapping in Pino or
 * Winston later means writing a new LogTransport and passing it into
 * createLogger — the public Logger interface and every existing caller
 * (`logger.info(...)`, `logger.child(...)`) stays exactly the same.
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

/**
 * Deliberately `Record<string, unknown>` rather than the stricter
 * JsonObject — callers frequently pass typed objects with optional
 * (possibly-undefined) properties, and this is a logging sink
 * (JSON.stringify drops undefined fine), not a wire contract.
 */
export type LogFields = Record<string, unknown>;

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  fields: LogFields;
}

export interface LogTransport {
  write(entry: LogEntry): void;
}

export const consoleTransport: LogTransport = {
  write(entry) {
    const line = JSON.stringify({
      level: entry.level,
      message: entry.message,
      timestamp: entry.timestamp,
      ...entry.fields,
    });

    if (entry.level === 'error') {
      console.error(line);
    } else if (entry.level === 'warn') {
      console.warn(line);
    } else {
      console.log(line);
    }
  },
};
