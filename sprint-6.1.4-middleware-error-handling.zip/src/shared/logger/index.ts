/**
 * Structured logger — every layer logs through this, never directly to
 * a transport (architecture-freeze-v1.md §6). Log levels and context
 * support are unchanged from the previous pass; emission is now behind
 * a swappable LogTransport (./transport.ts), so replacing console with
 * Pino/Winston later needs a new transport only — this file's public
 * Logger interface and every existing caller stay exactly the same.
 */

import type { LogLevel, LogFields, LogTransport } from './transport';
import { consoleTransport } from './transport';

export type { LogLevel, LogFields, LogTransport, LogEntry } from './transport';
export { consoleTransport } from './transport';

const LEVEL_WEIGHT: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

export interface LoggerOptions {
  /** Minimum level that gets emitted. Defaults to 'info'. */
  level?: LogLevel;
  /** Correlation fields (e.g. requestId/traceId) attached to every entry from this logger instance. */
  context?: LogFields;
  /** Emission target. Defaults to consoleTransport — pass a different one to swap in Pino/Winston later. */
  transport?: LogTransport;
}

export interface Logger {
  debug(message: string, fields?: LogFields): void;
  info(message: string, fields?: LogFields): void;
  warn(message: string, fields?: LogFields): void;
  error(message: string, fields?: LogFields): void;
  /** Returns a new Logger with additional context fields merged in (e.g. requestId). */
  child(context: LogFields): Logger;
}

export function createLogger(options: LoggerOptions = {}): Logger {
  const level = options.level ?? 'info';
  const context = options.context ?? {};
  const transport = options.transport ?? consoleTransport;

  function emit(entryLevel: LogLevel, message: string, fields?: LogFields): void {
    if (LEVEL_WEIGHT[entryLevel] < LEVEL_WEIGHT[level]) return;
    transport.write({
      level: entryLevel,
      message,
      timestamp: new Date().toISOString(),
      fields: { ...context, ...fields },
    });
  }

  return {
    debug: (message, fields) => emit('debug', message, fields),
    info: (message, fields) => emit('info', message, fields),
    warn: (message, fields) => emit('warn', message, fields),
    error: (message, fields) => emit('error', message, fields),
    child: (childContext) =>
      createLogger({ level, transport, context: { ...context, ...childContext } }),
  };
}

/** Root application logger. Server code derives a per-request child via `.child({ requestId })`. */
export const logger: Logger = createLogger();
