/**
 * Log-safe error serialization. Produces a plain object suitable for
 * structured logging (name, message, code, stack, details) — server-
 * side only, and never sent to a client. Kept separate from
 * error-mapper.ts, which produces the client-facing HTTP mapping and
 * must never include a stack trace.
 */

import { AppError } from './errors';

export interface SerializedError {
  name: string;
  message: string;
  code?: string;
  stack?: string;
  details?: unknown;
}

export function serializeErrorForLog(error: unknown): SerializedError {
  if (error instanceof AppError) {
    const withDetails = error as AppError & { details?: unknown };
    return {
      name: error.name,
      message: error.message,
      code: error.code,
      stack: error.stack,
      ...(withDetails.details !== undefined ? { details: withDetails.details } : {}),
    };
  }
  if (error instanceof Error) {
    return { name: error.name, message: error.message, stack: error.stack };
  }
  return { name: 'UnknownError', message: String(error) };
}
