/**
 * Standard route-handler wrapper ("asyncHandler" for the API layer).
 * Consolidates what routes were doing manually in Sprint 6.1.3: build a
 * RequestContext, start structured logging (via the existing
 * beginRequestLog — not reimplemented here), run the handler, log and
 * map any thrown error, and log completion with timing. No business
 * logic lives here — this only orchestrates existing pieces
 * (request-logging, serialize-error, error response).
 */

import { NextRequest, NextResponse } from 'next/server';
import { beginRequestLog } from './request-logging';
import { errorResponse } from '../http/response';
import { serializeErrorForLog } from '../errors/serialize-error';
import type { RequestContext } from '../../shared/types';
import type { Logger } from '../../shared/logger';

export interface RouteHandlerArgs {
  request: NextRequest;
  context: RequestContext;
  logger: Logger;
}

export type RouteHandler = (args: RouteHandlerArgs) => Promise<NextResponse> | NextResponse;

/**
 * Wraps a route handler with the standard request lifecycle.
 *
 *   export const GET = createRouteHandler('GET /v1/search', async ({ request, logger }) => {
 *     const query = validateSearchQuery(request.nextUrl.searchParams);
 *     return successResponse(...);
 *   });
 */
export function createRouteHandler(routeName: string, handler: RouteHandler) {
  return async function wrappedRoute(request: NextRequest): Promise<NextResponse> {
    const requestLog = beginRequestLog(request, routeName);

    try {
      const response = await handler({
        request,
        context: requestLog.context,
        logger: requestLog.logger,
      });
      requestLog.finish(response.status);
      return response;
    } catch (error) {
      requestLog.logger.error('request failed', {
        error: serializeErrorForLog(error),
      });
      const response = errorResponse(error);
      requestLog.finish(response.status);
      return response;
    }
  };
}
