/**
 * Generic request-inspection helpers. No auth/identity resolution and
 * no business logic — just safely reading well-known headers, for
 * logging/future-middleware to consume.
 */

export function getHeader(request: Request, name: string): string | undefined {
  return request.headers.get(name) ?? undefined;
}

/**
 * Best-effort client IP from common proxy headers. Returns undefined if
 * none present. This is a read helper only, not identity/auth
 * resolution — do not use this as an auth signal.
 */
export function getClientIp(request: Request): string | undefined {
  const forwardedFor = request.headers.get('x-forwarded-for');
  if (forwardedFor) {
    return forwardedFor.split(',')[0]?.trim();
  }
  return request.headers.get('x-real-ip') ?? undefined;
}
