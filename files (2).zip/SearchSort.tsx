'use client';

import { useId } from 'react';
import type { SearchSortOption } from '@/types/search';
import { cn } from '@/lib/utils';

interface SearchSortProps {
  value: SearchSortOption;
  onChange: (sort: SearchSortOption) => void;
  resultCount?: number;
  className?: string;
}

const SORT_OPTIONS: { value: SearchSortOption; label: string }[] = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
  { value: 'rating', label: 'Customer Rating' },
];

/**
 * Controlled sort dropdown over SearchSortOption (types/search.ts).
 * The parent is expected to feed `value` into lib/products.ts's
 * sortProducts() / filterProducts({ sort }).
 */
export function SearchSort({ value, onChange, resultCount, className }: SearchSortProps) {
  const sortId = useId();

  return (
    <div className={cn('flex flex-wrap items-center justify-between gap-3', className)}>
      {typeof resultCount === 'number' && (
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {resultCount.toLocaleString('en-IN')} result{resultCount === 1 ? '' : 's'}
        </p>
      )}
      <div className="flex items-center gap-2">
        <label htmlFor={sortId} className="text-sm font-medium text-foreground">
          Sort by
        </label>
        <select
          id={sortId}
          value={value}
          onChange={(e) => onChange(e.target.value as SearchSortOption)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
