'use client';

import { useId } from 'react';
import type { SearchFilters as SearchFiltersType } from '@/types/search';
import type { ProductCategorySlug } from '@/types/product';
import { STORES, type StoreSlug } from '@/types/store';
import { cn } from '@/lib/utils';

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onChange: (filters: SearchFiltersType) => void;
  className?: string;
}

const CATEGORY_OPTIONS: { value: ProductCategorySlug; label: string }[] = [
  { value: 'mobiles', label: 'Mobiles' },
  { value: 'laptops', label: 'Laptops' },
  { value: 'audio', label: 'Audio' },
  { value: 'televisions', label: 'Televisions' },
  { value: 'wearables', label: 'Wearables' },
  { value: 'home_appliances', label: 'Home Appliances' },
  { value: 'cameras', label: 'Cameras' },
];

const STORE_OPTIONS = Object.values(STORES);

/**
 * Controlled filters panel over the SearchFilters shape from
 * types/search.ts. Purely UI state — the parent owns `filters` and is
 * expected to pass it into lib/products.ts's filterProducts()/runSearch().
 */
export function SearchFilters({ filters, onChange, className }: SearchFiltersProps) {
  const categoryId = useId();
  const minPriceId = useId();
  const maxPriceId = useId();
  const ratingId = useId();

  function toggleStore(store: StoreSlug) {
    const current = filters.stores ?? [];
    const next = current.includes(store)
      ? current.filter((s) => s !== store)
      : [...current, store];
    onChange({ ...filters, stores: next.length > 0 ? next : undefined });
  }

  function handleReset() {
    onChange({ query: filters.query, sort: filters.sort });
  }

  return (
    <section
      aria-label="Search filters"
      className={cn('flex flex-col gap-5 rounded-xl border border-border bg-card p-4', className)}
    >
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">Filters</h2>
        <button
          type="button"
          onClick={handleReset}
          className="rounded text-xs font-medium text-muted-foreground underline-offset-2 hover:text-foreground hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Reset
        </button>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor={categoryId} className="text-xs font-medium text-foreground">
          Category
        </label>
        <select
          id={categoryId}
          value={filters.category ?? ''}
          onChange={(e) =>
            onChange({
              ...filters,
              category: e.target.value ? (e.target.value as ProductCategorySlug) : undefined,
            })
          }
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          <option value="">All categories</option>
          {CATEGORY_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      <fieldset className="flex flex-col gap-2">
        <legend className="text-xs font-medium text-foreground">Stores</legend>
        <div className="flex flex-col gap-2">
          {STORE_OPTIONS.map((store) => {
            const checked = filters.stores?.includes(store.slug) ?? false;
            return (
              <label
                key={store.slug}
                className="flex cursor-pointer items-center gap-2 text-sm text-foreground"
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggleStore(store.slug)}
                  className="h-4 w-4 rounded border-border text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                />
                {store.name}
              </label>
            );
          })}
        </div>
      </fieldset>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <label htmlFor={minPriceId} className="text-xs font-medium text-foreground">
            Min price
          </label>
          <input
            id={minPriceId}
            type="number"
            min={0}
            inputMode="numeric"
            value={filters.minPrice ?? ''}
            onChange={(e) =>
              onChange({
                ...filters,
                minPrice: e.target.value ? Number(e.target.value) : undefined,
              })
            }
            placeholder="₹0"
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label htmlFor={maxPriceId} className="text-xs font-medium text-foreground">
            Max price
          </label>
          <input
            id={maxPriceId}
            type="number"
            min={0}
            inputMode="numeric"
            value={filters.maxPrice ?? ''}
            onChange={(e) =>
              onChange({
                ...filters,
                maxPrice: e.target.value ? Number(e.target.value) : undefined,
              })
            }
            placeholder="Any"
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          />
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor={ratingId} className="text-xs font-medium text-foreground">
          Minimum rating
        </label>
        <select
          id={ratingId}
          value={filters.minRating ?? ''}
          onChange={(e) =>
            onChange({
              ...filters,
              minRating: e.target.value ? Number(e.target.value) : undefined,
            })
          }
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          <option value="">Any rating</option>
          <option value="4.5">4.5 &amp; up</option>
          <option value="4">4 &amp; up</option>
          <option value="3.5">3.5 &amp; up</option>
          <option value="3">3 &amp; up</option>
        </select>
      </div>
    </section>
  );
}
