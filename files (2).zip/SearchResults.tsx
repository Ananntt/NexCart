import type { Product } from '@/types/product';
import { ProductCard } from '@/components/product/ProductCard';
import { cn } from '@/lib/utils';

interface SearchResultsProps {
  products: Product[];
  className?: string;
}

/**
 * Renders a responsive grid of ProductCard results, or an empty state.
 * Takes an already-filtered/sorted Product[] — callers build this list
 * with lib/products.ts (filterProducts / sortProducts / runSearch).
 * This component does not fetch, filter, or sort on its own.
 */
export function SearchResults({ products, className }: SearchResultsProps) {
  if (products.length === 0) {
    return (
      <div
        role="status"
        className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border py-16 text-center"
      >
        <p className="text-sm font-medium text-foreground">No products found</p>
        <p className="text-sm text-muted-foreground">
          Try adjusting your filters or searching for something else.
        </p>
      </div>
    );
  }

  return (
    <ul
      className={cn(
        'grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5',
        className
      )}
    >
      {products.map((product) => (
        <li key={product.id} className="list-none">
          <ProductCard product={product} className="h-full" />
        </li>
      ))}
    </ul>
  );
}
