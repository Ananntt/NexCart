import Image from 'next/image';
import Link from 'next/link';
import type { Product } from '@/types/product';
import { StoreBadge } from './StoreBadge';
import { PriceCard } from './PriceCard';
import { cn } from '@/lib/utils';

interface ProductCardProps {
  product: Product;
  className?: string;
}

const STOCK_STYLES: Record<Product['stockStatus'], string> = {
  in_stock: 'text-emerald-600',
  limited: 'text-amber-600',
  out_of_stock: 'text-red-600',
};

const STOCK_LABELS: Record<Product['stockStatus'], string> = {
  in_stock: 'In stock',
  limited: 'Limited stock',
  out_of_stock: 'Out of stock',
};

/**
 * Single product result card. Consumes the Product type from
 * types/product.ts as-is — no data fetching or filtering here, that
 * belongs to lib/products.ts and the parent search components.
 */
export function ProductCard({ product, className }: ProductCardProps) {
  const isOutOfStock = product.stockStatus === 'out_of_stock';

  return (
    <article
      className={cn(
        'group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card transition-shadow hover:shadow-md focus-within:shadow-md',
        className
      )}
    >
      <div className="relative aspect-square w-full overflow-hidden bg-muted">
        <Image
          src={product.image}
          alt={product.title}
          fill
          sizes="(min-width: 1024px) 20vw, (min-width: 640px) 33vw, 50vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute left-2 top-2">
          <StoreBadge store={product.store} />
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-3">
        <h3 className="line-clamp-2 text-sm font-medium leading-snug text-foreground">
          {product.title}
        </h3>

        <p className="text-xs text-muted-foreground">{product.brand}</p>

        <div
          className="flex items-center gap-1 text-xs"
          aria-label={`Rated ${product.rating.average} out of 5 from ${product.rating.count} reviews`}
        >
          <span aria-hidden="true" className="text-amber-500">
            ★
          </span>
          <span className="font-medium text-foreground">{product.rating.average.toFixed(1)}</span>
          <span className="text-muted-foreground">
            ({product.rating.count.toLocaleString('en-IN')})
          </span>
        </div>

        <PriceCard price={product.price} />

        <p className={cn('text-xs font-medium', STOCK_STYLES[product.stockStatus])}>
          {STOCK_LABELS[product.stockStatus]}
          {!isOutOfStock && (
            <span className="ml-1 font-normal text-muted-foreground">
              · Delivery in {product.deliveryEtaDays} day{product.deliveryEtaDays === 1 ? '' : 's'}
            </span>
          )}
        </p>

        <Link
          href={product.productUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-disabled={isOutOfStock}
          tabIndex={isOutOfStock ? -1 : undefined}
          className={cn(
            'mt-auto inline-flex items-center justify-center rounded-lg border border-border px-3 py-2 text-sm font-medium transition-colors',
            isOutOfStock
              ? 'pointer-events-none cursor-not-allowed bg-muted text-muted-foreground'
              : 'bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring'
          )}
        >
          {isOutOfStock ? 'Unavailable' : `View on ${product.store.replace('_', ' ')}`}
        </Link>
      </div>
    </article>
  );
}
