import { STORES, type StoreSlug } from '@/types/store';
import { cn } from '@/lib/utils';

interface StoreBadgeProps {
  store: StoreSlug;
  className?: string;
}

/**
 * Small pill badge identifying which storefront a product/offer is from.
 * Purely presentational — reads its label/color from the STORES map in
 * types/store.ts so adding a new store is a one-line change there.
 */
export function StoreBadge({ store, className }: StoreBadgeProps) {
  const info = STORES[store];

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border border-white/60 bg-white/90 px-2 py-0.5 text-[11px] font-semibold shadow-sm backdrop-blur-sm dark:border-black/40 dark:bg-black/70',
        className
      )}
      style={{ color: info.color }}
    >
      {info.name}
    </span>
  );
}
