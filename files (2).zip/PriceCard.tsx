import type { ProductPrice } from '@/types/product';
import { cn } from '@/lib/utils';

interface PriceCardProps {
  price: ProductPrice;
  className?: string;
}

const formatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

/**
 * Renders current price, struck-through MRP, and discount percentage.
 * Pure presentational component over the ProductPrice shape from
 * types/product.ts — no calculation happens here (discountPercent is
 * pre-computed by lib/products.ts).
 */
export function PriceCard({ price, className }: PriceCardProps) {
  const hasDiscount = price.discountPercent > 0 && price.mrp > price.current;

  return (
    <div className={cn('flex flex-wrap items-baseline gap-2', className)}>
      <span className="text-base font-semibold text-foreground">
        {formatter.format(price.current)}
      </span>
      {hasDiscount && (
        <>
          <span className="text-xs text-muted-foreground line-through">
            {formatter.format(price.mrp)}
          </span>
          <span className="text-xs font-semibold text-emerald-600">
            {price.discountPercent}% off
          </span>
        </>
      )}
    </div>
  );
}
