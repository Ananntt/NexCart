'use client';

import { Suspense, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import type { SearchFilters as SearchFiltersType, SearchSortOption } from '@/types/search';
import { filterProducts } from '@/lib/products';
import { SearchFilters } from '@/components/search/SearchFilters';
import { SearchSort } from '@/components/search/SearchSort';
import { SearchResults } from '@/components/search/SearchResults';

/**
 * /search — browse/search the mock product catalogue (lib/products.ts).
 *
 * Frontend-only page standing in for the real `GET /v1/search` endpoint
 * (docs/api.md §2.1) ahead of the backend/search-engine implementation.
 * All filtering/sorting happens client-side over the static PRODUCTS
 * dataset via the existing filterProducts()/sortProducts() helpers, so
 * this page can later be swapped to call the real endpoint without
 * changing SearchFilters/SearchSort/SearchResults themselves.
 */
function SearchPageContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') ?? '';

  const [filters, setFilters] = useState<SearchFiltersType>({
    query: initialQuery || undefined,
    sort: 'relevance',
  });

  const results = useMemo(() => filterProducts(filters), [filters]);

  function handleSortChange(sort: SearchSortOption) {
    setFilters((prev) => ({ ...prev, sort }));
  }

  return (
    <main className="mx-auto flex w-full max-w-7xl flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
      <header className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold text-foreground sm:text-2xl">
          {filters.query ? `Results for "${filters.query}"` : 'All products'}
        </h1>
        <p className="text-sm text-muted-foreground">
          Compare prices across Amazon, Flipkart, Croma, Reliance Digital and Vijay Sales.
        </p>
      </header>

      <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:gap-8">
        <aside className="w-full shrink-0 lg:sticky lg:top-6 lg:w-64">
          <SearchFilters filters={filters} onChange={setFilters} />
        </aside>

        <section className="flex min-w-0 flex-1 flex-col gap-4" aria-live="polite">
          <SearchSort
            value={filters.sort ?? 'relevance'}
            onChange={handleSortChange}
            resultCount={results.length}
          />

          <SearchResults products={results} />
        </section>
      </div>
    </main>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={null}>
      <SearchPageContent />
    </Suspense>
  );
}
