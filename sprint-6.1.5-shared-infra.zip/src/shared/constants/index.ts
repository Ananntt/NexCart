/**
 * Shared, cross-cutting constants. Only values with an actual current
 * call site live here — no speculative/unused entries (e.g. timeout
 * constants are deferred until provider/search code exists to use
 * them; HTTP header name and content-type constants are deferred until
 * a file that currently hardcodes them is otherwise being modified).
 */

/**
 * Error-code constants (api.md §10: "one shared enum/constants file
 * across the API surface, so frontend error handling can switch on
 * error.code rather than parsing message strings").
 *
 * Only generic, cross-cutting codes live here. Endpoint-specific codes
 * (e.g. EMAIL_TAKEN, DUPLICATE_REVIEW, ALREADY_FAVORITED) are added
 * alongside the feature/sprint that introduces them.
 */
export const ERROR_CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_PRICE_RANGE: 'INVALID_PRICE_RANGE',
  NOT_FOUND: 'NOT_FOUND',
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
} as const;

export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];

/** HTTP status codes actually used by error-mapper.ts / response.ts (api.md §0.5). */
export const HTTP_STATUS = {
  OK: 200,
  BAD_REQUEST: 400,
  NOT_FOUND: 404,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
} as const;

export type HttpStatus = (typeof HTTP_STATUS)[keyof typeof HTTP_STATUS];

/** Pagination defaults matching api.md §0.7 (`?page=1&limit=20`, max `limit=100`). */
export const PAGINATION_DEFAULTS = {
  DEFAULT_PAGE: 1,
  MIN_PAGE: 1,
  DEFAULT_LIMIT: 20,
  MIN_LIMIT: 1,
  MAX_LIMIT: 100,
} as const;

/** Field-length limits currently enforced by a validator (api.md §2.1 `q`: 1-200 chars). */
export const API_LIMITS = {
  QUERY_MIN_LENGTH: 1,
  QUERY_MAX_LENGTH: 200,
} as const;
