/**
 * Maps domain errors (./errors.ts) to the HTTP status codes defined in
 * api.md §0.5. This is the only place that translates a domain error
 * into an HTTP concern — everything below the HTTP layer stays
 * status-code-agnostic.
 *
 * Named error-mapper.ts per architecture-freeze-v1.md §4 (renamed from
 * the working-name status-map.ts during Sprint 6.1).
 */

import {
  AppError,
  ValidationError,
  InvalidRangeError,
  NotFoundError,
  RateLimitError,
  InternalError,
} from './errors';
import { ERROR_CODES, HTTP_STATUS, type ErrorCode } from '../../shared/constants';
import type { ValidationIssue } from './errors';

export interface MappedError {
  status: number;
  code: ErrorCode;
  message: string;
  details?: ValidationIssue[];
  retryAfterSeconds?: number;
}

export function mapErrorToHttp(error: unknown): MappedError {
  if (error instanceof ValidationError) {
    return { status: HTTP_STATUS.BAD_REQUEST, code: error.code, message: error.message, details: error.details };
  }
  if (error instanceof InvalidRangeError) {
    return { status: HTTP_STATUS.UNPROCESSABLE_ENTITY, code: error.code, message: error.message };
  }
  if (error instanceof NotFoundError) {
    return { status: HTTP_STATUS.NOT_FOUND, code: error.code, message: error.message };
  }
  if (error instanceof RateLimitError) {
    return {
      status: HTTP_STATUS.TOO_MANY_REQUESTS,
      code: error.code,
      message: error.message,
      retryAfterSeconds: error.retryAfterSeconds,
    };
  }
  if (error instanceof InternalError) {
    return { status: HTTP_STATUS.INTERNAL_SERVER_ERROR, code: error.code, message: error.message };
  }
  if (error instanceof AppError) {
    // A future error subclass not yet explicitly mapped above — fail safe (500), never silently 200.
    return { status: HTTP_STATUS.INTERNAL_SERVER_ERROR, code: ERROR_CODES.INTERNAL_ERROR, message: error.message };
  }

  // Truly unexpected (non-AppError) exception — never leak internals in the message.
  return { status: HTTP_STATUS.INTERNAL_SERVER_ERROR, code: ERROR_CODES.INTERNAL_ERROR, message: 'Internal server error' };
}
