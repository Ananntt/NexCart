/**
 * Framework-independent parsing helpers — pure functions over plain
 * strings, not Next.js Request/Response objects.
 */

import { parseOptionalNumber } from '../../validation/validators';

const TRUTHY = ['true', '1', 'yes', 'on'];
const FALSY = ['false', '0', 'no', 'off'];

/** Parses common truthy/falsy string representations into a boolean. Returns undefined if absent/unrecognized. */
export function parseBoolean(value: string | null | undefined): boolean | undefined {
  if (value === null || value === undefined) return undefined;
  const normalized = value.trim().toLowerCase();
  if (TRUTHY.includes(normalized)) return true;
  if (FALSY.includes(normalized)) return false;
  return undefined;
}

/**
 * Parses a string into a number. Alias of the existing
 * `validation/validators.ts` implementation, re-exported here so all
 * `parseX` helpers have one home — not a reimplementation.
 */
export const parseNumber = parseOptionalNumber;

/** Parses a string into one of a fixed set of allowed values, or undefined if it doesn't match. */
export function parseEnum<T extends string>(
  value: string | null | undefined,
  allowed: readonly T[]
): T | undefined {
  if (value === null || value === undefined) return undefined;
  return (allowed as readonly string[]).includes(value) ? (value as T) : undefined;
}
