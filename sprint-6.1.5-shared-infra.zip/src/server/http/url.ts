/**
 * Pure, framework-independent URL/header helpers — no fetch, no
 * Request/Response objects, no Next.js imports.
 */

/** Builds a URL string from a base and query params, omitting undefined/null values. */
export function buildUrl(
  base: string,
  params?: Record<string, string | number | boolean | undefined | null>
): string {
  if (!params) return base;
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null);
  if (entries.length === 0) return base;

  const query = entries
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`)
    .join('&');

  const separator = base.includes('?') ? '&' : '?';
  return `${base}${separator}${query}`;
}

/**
 * Normalizes a plain headers-like object to lowercase keys with trimmed
 * values, dropping undefined/null entries. Operates on plain objects,
 * not a Headers instance.
 */
export function normalizeHeaders(
  headers: Record<string, string | undefined | null>
): Record<string, string> {
  const normalized: Record<string, string> = {};
  for (const [key, value] of Object.entries(headers)) {
    if (value === undefined || value === null) continue;
    normalized[key.toLowerCase().trim()] = value.trim();
  }
  return normalized;
}
