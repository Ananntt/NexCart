/**
 * Standard response envelope builders (api.md §0.3 / §0.4) and their
 * types/guards. Extended in Sprint 6.1.4 with a `verbose` hook on
 * errorResponse so a future `config.isDevelopment` can be passed in
 * directly with no refactor here — see ErrorResponseOptions below. The
 * client-facing shape is unchanged and never includes stack traces or
 * internals; that stays in serialize-error.ts for server-side logging
 * only.
 */

import { NextResponse } from 'next/server';
import { mapErrorToHttp } from '../errors/error-mapper';
import type { ValidationIssue } from '../errors/errors';
import { HTTP_STATUS } from '../../shared/constants';

/** Fully-populated pagination metadata (api.md §0.7). Single source of truth for the shape — `SuccessMeta` is this made optional. */
export interface PaginationInfo {
  page: number;
  limit: number;
  total: number;
}

/** Builds a PaginationInfo object — avoids hand-assembling `{ page, limit, total }` at each call site. */
export function buildPaginationInfo(page: number, limit: number, total: number): PaginationInfo {
  return { page, limit, total };
}

export type SuccessMeta = Partial<PaginationInfo>;

export interface ApiSuccessEnvelope<T> {
  success: true;
  data: T;
  meta?: SuccessMeta;
}

export interface ApiErrorEnvelope {
  success: false;
  error: {
    code: string;
    message: string;
    details?: ValidationIssue[];
  };
}

/** Type guard for a parsed response body — useful for clients/tests consuming the envelope. */
export function isSuccessEnvelope<T = unknown>(value: unknown): value is ApiSuccessEnvelope<T> {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as { success?: unknown }).success === true &&
    'data' in value
  );
}

/** Type guard for a parsed error response body. */
export function isErrorEnvelope(value: unknown): value is ApiErrorEnvelope {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as { success?: unknown }).success === false &&
    typeof (value as { error?: unknown }).error === 'object'
  );
}

export function successResponse<T>(
  data: T,
  init?: { status?: number; meta?: SuccessMeta }
): NextResponse {
  const body: ApiSuccessEnvelope<T> = { success: true, data };
  if (init?.meta) body.meta = init.meta;
  return NextResponse.json(body, { status: init?.status ?? HTTP_STATUS.OK });
}

export interface ErrorResponseOptions {
  /**
   * Reserved integration hook for Config, which doesn't exist yet.
   * Defaults to false and is currently unused — client responses stay
   * safe-by-default regardless of this flag. Once `src/config/env.ts`
   * lands, callers pass `{ verbose: config.isDevelopment }` and this
   * function starts honoring it; no other refactor is required.
   */
  verbose?: boolean;
}

export function errorResponse(
  error: unknown,
  options: ErrorResponseOptions = {}
): NextResponse {
  const { verbose = false } = options;
  void verbose; // unused until Config exists — see ErrorResponseOptions doc above

  const mapped = mapErrorToHttp(error);

  const body: ApiErrorEnvelope = {
    success: false,
    error: {
      code: mapped.code,
      message: mapped.message,
      ...(mapped.details ? { details: mapped.details } : {}),
    },
  };

  const headers: Record<string, string> = {};
  if (mapped.retryAfterSeconds !== undefined) {
    headers['Retry-After'] = String(mapped.retryAfterSeconds);
  }

  return NextResponse.json(body, { status: mapped.status, headers });
}
