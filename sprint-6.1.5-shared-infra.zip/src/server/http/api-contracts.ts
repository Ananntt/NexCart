/**
 * Convenience type aliases over the canonical envelope types defined in
 * `./response.ts` — the single source of truth for response shape.
 * Nothing here redefines the envelope; these are naming conveniences
 * (SuccessResponse, ErrorResponse, Metadata) plus two additive generics
 * (ApiRequest, PaginatedResponse) that response.ts has no reason to own.
 */

import type { ApiSuccessEnvelope, ApiErrorEnvelope, SuccessMeta, PaginationInfo } from './response';

/** Alias of the canonical success envelope (./response.ts). */
export type SuccessResponse<T> = ApiSuccessEnvelope<T>;

/** Alias of the canonical error envelope (./response.ts). */
export type ErrorResponse = ApiErrorEnvelope;

/** Union of every possible API response shape for a given data type. */
export type ApiResponse<T> = SuccessResponse<T> | ErrorResponse;

/** Alias of the canonical (optional) pagination meta shape. */
export type Metadata = SuccessMeta;

/** A success envelope whose data is a list and whose meta is fully-populated pagination info. */
export interface PaginatedResponse<T> extends ApiSuccessEnvelope<T[]> {
  meta: PaginationInfo;
}

/**
 * Minimal, framework-agnostic description of an incoming request's
 * validated shape — not a Next.js Request. `TQuery`/`TBody` are filled
 * in by each endpoint's own validator (e.g. SearchQueryInput).
 */
export interface ApiRequest<TQuery = unknown, TBody = unknown> {
  query: TQuery;
  body?: TBody;
}
