/**
 * Generic query-string parsing helpers, reusable by any future
 * endpoint. Distinct from `validation.ts` in this folder, which is the
 * search-endpoint-specific validator from Sprint 6.1.3 and is left
 * untouched. Reuses `src/validation/validators.ts` rather than
 * reimplementing number parsing.
 */

import { parseOptionalNumber } from '../../validation/validators';
import { PAGINATION_DEFAULTS } from '../../shared/constants';

/** Parses a comma-separated query param into a trimmed, non-empty string array, or undefined if absent. */
export function parseQueryArray(searchParams: URLSearchParams, key: string): string[] | undefined {
  const raw = searchParams.get(key);
  if (!raw) return undefined;
  const values = raw.split(',').map((v) => v.trim()).filter(Boolean);
  return values.length > 0 ? values : undefined;
}

/** Parses a query param into a number. Returns undefined if absent, NaN if present but invalid. */
export function parseQueryNumber(searchParams: URLSearchParams, key: string): number | undefined {
  return parseOptionalNumber(searchParams.get(key));
}

/** Parses a query param into an integer, clamped to [min, max], falling back if absent/invalid. */
export function parseQueryInt(
  searchParams: URLSearchParams,
  key: string,
  options: { fallback: number; min?: number; max?: number }
): number {
  const raw = parseOptionalNumber(searchParams.get(key));
  if (raw === undefined || Number.isNaN(raw)) return options.fallback;
  let value = Math.floor(raw);
  if (options.min !== undefined) value = Math.max(value, options.min);
  if (options.max !== undefined) value = Math.min(value, options.max);
  return value;
}

/** Reads a single string query param, trimmed. Returns undefined if absent/blank. */
export function parseQueryString(searchParams: URLSearchParams, key: string): string | undefined {
  const raw = searchParams.get(key);
  const trimmed = raw?.trim();
  return trimmed ? trimmed : undefined;
}

/** Parses `page`/`limit` query params into validated pagination values (api.md §0.7 defaults). */
export function parsePagination(searchParams: URLSearchParams): { page: number; limit: number } {
  const page = parseQueryInt(searchParams, 'page', {
    fallback: PAGINATION_DEFAULTS.DEFAULT_PAGE,
    min: PAGINATION_DEFAULTS.MIN_PAGE,
  });
  const limit = parseQueryInt(searchParams, 'limit', {
    fallback: PAGINATION_DEFAULTS.DEFAULT_LIMIT,
    min: PAGINATION_DEFAULTS.MIN_LIMIT,
    max: PAGINATION_DEFAULTS.MAX_LIMIT,
  });
  return { page, limit };
}
